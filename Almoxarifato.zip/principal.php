<?php

session_start();
if (!isset($_SESSION['usuario_id'])) {
    
    header("Location: login.html");
    exit();
}


include 'conexao.php';


echo "<h2>Bem-vindo, " . $_SESSION['usuario_login'] . "!</h2>";


echo "<ul>
        <li><a href='cadastro_ferramenta.php'>Cadastrar Ferramenta</a></li>
        <li><a href='visualizar_ferramentas.php'>Visualizar Ferramentas</a></li>
        <!-- Adicione links para editar e excluir ferramentas, se necessário -->
      </ul>";


?>
