<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (isset($_POST["login"]) && isset($_POST["senha"])) {
        
        include 'conexao.php';

       
        $login_usuario = $_POST["login"];
        $senha_usuario = $_POST["senha"];

       
        $sql_verificar = "SELECT * FROM tb_usuario WHERE login_usuario = '$login_usuario'";
        $resultado = $conn->query($sql_verificar);

        if ($resultado->num_rows > 0) {
            echo "Erro: Este usuário já existe.";
        } else {
          
            $sql = "INSERT INTO tb_usuario (login_usuario, senha_usuario) VALUES ('$login_usuario', '$senha_usuario')";

           
            if ($conn->query($sql) === TRUE) {
                echo "Usuário cadastrado com sucesso!";
            } else {
                echo "Erro ao cadastrar usuário: " . $conn->error;
            }
        }

        
        $conn->close();
    } else {
        echo "Por favor, preencha todos os campos.";
    }
} else {
    echo "Acesso inválido!";
}
?>
