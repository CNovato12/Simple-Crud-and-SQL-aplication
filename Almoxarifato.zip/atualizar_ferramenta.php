<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Ferramenta</title>
</head>
<body>
    <?php
    
    session_start();

   
    if (!isset($_SESSION['login'])) {
        header("Location: login.html");
        exit();
    }

   
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
       
        if (isset($_POST['id']) && isset($_POST['nome']) && isset($_POST['marca'])) {
           
            $servername = "localhost"; 
            $username = "root";
            $password = "";
            $dbname = "almoxarifato";

            $conn = new mysqli($servername, $username, $password, $dbname);

         
            if ($conn->connect_error) {
                die("Conexão falhou: " . $conn->connect_error);
            }

           
            $sql = "UPDATE tb_ferramentas SET nome_ferramenta = ?, marca_ferramenta = ? WHERE cod_ferramenta = ?";

            if ($stmt = $conn->prepare($sql)) {
               
                $stmt->bind_param("ssi", $_POST['nome'], $_POST['marca'], $_POST['id']);

            
                if ($stmt->execute()) {
                    echo "Ferramenta atualizada com sucesso.";
                } else {
                    echo "Erro ao atualizar a ferramenta: " . $conn->error;
                }

                
                $stmt->close();
            }

            
            $conn->close();
        } else {
            echo "Todos os campos são obrigatórios.";
        }
    } else {
        echo "Método de solicitação inválido.";
    }
    ?>

    <!-- Botão de voltar -->
    <a href="visualizar_ferramentas.php">Voltar para Visualizar Ferramentas</a>
</body>
</html>
