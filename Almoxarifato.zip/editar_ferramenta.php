<?php

session_start();


if (!isset($_SESSION['login'])) {
    header("Location: login.html");
    exit();
}


if(isset($_GET['id']) && !empty($_GET['id'])) {
   
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "almoxarifato";

    $conn = new mysqli($servername, $username, $password, $dbname);

    
    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    
    $sql = "SELECT * FROM tb_ferramentas WHERE cod_ferramenta = ?";
    
    if ($stmt = $conn->prepare($sql)) {
       
        $stmt->bind_param("i", $_GET['id']);

       
        $stmt->execute();

       
        $result = $stmt->get_result();

       
        if ($result->num_rows > 0) {
           
            $ferramenta = $result->fetch_assoc();
        } else {
            echo "Ferramenta não encontrada.";
            exit();
        }

        
        $stmt->close();
    }

    
    $conn->close();
} else {
    echo "ID da ferramenta não fornecido.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Ferramenta</title>
</head>
<body>
    <h2>Editar Ferramenta</h2>
    <form action="atualizar_ferramenta.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $ferramenta['cod_ferramenta']; ?>">
        <label for="nome">Nome:</label><br>
        <input type="text" id="nome" name="nome" value="<?php echo $ferramenta['nome_ferramenta']; ?>"><br>
        <label for="marca">Marca:</label><br>
        <input type="text" id="marca" name="marca" value="<?php echo $ferramenta['marca_ferramenta']; ?>"><br><br>
        <input type="submit" value="Salvar">
    </form>
</body>
</html>
