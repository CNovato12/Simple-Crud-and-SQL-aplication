<?php

session_start();


if (!isset($_SESSION['login'])) {
    header("Location: login.html");
    exit();
}


if(isset($_GET['id']) && !empty($_GET['id'])) {
   
    $servername = "localhost"; 
    $username = "root";
    $password = "";
    $dbname = "almoxarifato";

    $conn = new mysqli($servername, $username, $password, $dbname);

    
    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    
    $sql = "DELETE FROM tb_ferramentas WHERE cod_ferramenta = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        
        $stmt->bind_param("i", $_GET['id']);

       
        if ($stmt->execute()) {
            echo "Ferramenta excluída com sucesso.";
        } else {
            echo "Erro ao excluir ferramenta: " . $conn->error;
        }

        
        $stmt->close();
    }

    
    $conn->close();
} else {
    echo "ID da ferramenta não fornecido.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Ferramenta</title>
</head>
<body>
    <p>
        
        <a href="visualizar_ferramentas.php">Voltar para Visualizar Ferramentas</a>
    </p>
</body>
</html>
