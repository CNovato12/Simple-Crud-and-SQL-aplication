<?php

session_start();


if (!isset($_SESSION['login'])) {
    header("Location: login.html");
    exit();
}

$localhost = "localhost";
$username = "root";
$password = "";
$dbname = "almoxarifato";

$conn = new mysqli($localhost, $username, $password, $dbname);


if ($conn->connect_error) {
    die("connection failed : " . $conn->connect_error);
}


$sql = "SELECT * FROM tb_ferramentas";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Ferramentas</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Visualizar Ferramentas</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome da Ferramenta</th>
            <th>Marca da Ferramenta</th>
            <th>Ações</th>
        </tr>
        <?php
       
        if ($result) {
           
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["cod_ferramenta"] . "</td>";
                    echo "<td>" . $row["nome_ferramenta"] . "</td>";
                    echo "<td>" . $row["marca_ferramenta"] . "</td>";
                    echo "<td><a href='editar_ferramenta.php?id=" . $row["cod_ferramenta"] . "'>Editar</a> | <a href='excluir_ferramenta.php?id=" . $row["cod_ferramenta"] . "'>Excluir</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>Nenhuma ferramenta encontrada</td></tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Erro ao recuperar dados das ferramentas</td></tr>";
        }
        ?>
    </table>

  
    <a href="gerenciar_ferramentas.php">Voltar para Gerenciar Ferramentas</a>
</body>
</html>

<?php

if(isset($conn)) {
    $conn->close();
}
?>
