<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $login = $_POST['login'];
    $senha = $_POST['senha'];

  
    $localhost 	= "localhost"; 
    $username 	= "root"; 
    $password 	= ""; 
    $dbname 	= "almoxarifato"; 
     
    $conn = new mysqli($localhost, $username, $password, $dbname); 
    
    if($conn->connect_error) {
        die("connection failed : " . $conn->connect_error);
    }

    
    $sql = "SELECT * FROM tb_usuario WHERE login_usuario='$login'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if ($senha == $row['senha_usuario']) {
           
            $_SESSION['login'] = $login;
            header("Location: gerenciar_ferramentas.php");
            exit();
        } else {
           
            header("Location: login.html?erro=senha");
            exit();
        }
    } else {
        
        header("Location: login.html?erro=usuario");
        exit();
    }

    
    $conn->close();
} else {

    header("Location: login.html");
    exit();
}
?>
