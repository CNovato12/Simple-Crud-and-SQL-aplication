<?php
session_start();


if (!isset($_SESSION['login'])) {
    header("Location: login.html");
    exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $nome_ferramenta = $_POST['nome_ferramenta'];
    $marca_ferramenta = $_POST['marca_ferramenta'];

   

    $localhost 	= "localhost"; 
    $username 	= "root"; 
    $password 	= ""; 
    $dbname 	= "almoxarifato"; 
     
    $conn = new mysqli($localhost, $username, $password, $dbname); 
    
    if($conn->connect_error) {
        die("connection failed : " . $conn->connect_error);
    }

    
    $sql = "INSERT INTO tb_ferramentas (nome_ferramenta, marca_ferramenta) VALUES ('$nome_ferramenta', '$marca_ferramenta')";

    if ($conn->query($sql) === TRUE) {
        echo "Ferramenta cadastrada com sucesso!";
        
        header("Location: gerenciar_ferramentas.php");
        exit();
    } else {
        echo "Erro ao cadastrar ferramenta: " . $conn->error;
    }

   
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Ferramenta</title>
</head>
<body>
    <h1>Cadastrar Ferramenta</h1>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="nome_ferramenta">Nome da Ferramenta:</label>
        <input type="text" id="nome_ferramenta" name="nome_ferramenta"><br>
        <label for="marca_ferramenta">Marca da Ferramenta:</label>
        <input type="text" id="marca_ferramenta" name="marca_ferramenta"><br>
        <input type="submit" value="Cadastrar">
    </form>
    <!-- Botão de voltar -->
    <a href="gerenciar_ferramentas.php">Voltar para Gerenciar Ferramentas</a>
</body>
</html>
