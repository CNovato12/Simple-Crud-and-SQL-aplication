<?php

session_start();


if (!isset($_SESSION['login'])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Ferramentas</title>
</head>
<body>
    <h1>Gerenciar Ferramentas</h1>
    <h2>O que deseja fazer?</h2>
    <ul>
        <li><a href="cadastrar_ferramenta.php">Cadastrar Ferramenta</a></li>
        <li><a href="visualizar_ferramentas.php">Visualizar Ferramentas</a></li>
        <li><a href="logout.php">Sair</a></li>
    </ul>
</body>
</html>
